package fr.maxlego08.zauctionhouse.zcore.utils.interfaces;

@FunctionalInterface
public interface StringConsumer<T> {
  String accept(T paramT);
}


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\zcor\\utils\interfaces\StringConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */