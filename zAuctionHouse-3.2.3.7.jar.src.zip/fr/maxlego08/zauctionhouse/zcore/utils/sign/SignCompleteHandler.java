package fr.maxlego08.zauctionhouse.zcore.utils.sign;

@FunctionalInterface
public interface SignCompleteHandler {
  void onSignClose(UpdateSignEvent paramUpdateSignEvent);
}


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\zcor\\utils\sign\SignCompleteHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */