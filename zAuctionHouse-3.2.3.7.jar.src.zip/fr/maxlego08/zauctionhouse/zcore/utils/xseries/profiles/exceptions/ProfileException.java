/*    */ package fr.maxlego08.zauctionhouse.zcore.utils.xseries.profiles.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProfileException
/*    */   extends RuntimeException
/*    */ {
/*    */   public ProfileException() {}
/*    */   
/*    */   public ProfileException(String paramString) {
/* 33 */     super(paramString);
/*    */   }
/*    */   
/*    */   public ProfileException(String paramString, Throwable paramThrowable) {
/* 37 */     super(paramString, paramThrowable);
/*    */   }
/*    */   
/*    */   public ProfileException(Throwable paramThrowable) {
/* 41 */     super(paramThrowable);
/*    */   }
/*    */   
/*    */   public ProfileException(String paramString, Throwable paramThrowable, boolean paramBoolean1, boolean paramBoolean2) {
/* 45 */     super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
/*    */   }
/*    */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\zcor\\utils\xseries\profiles\exceptions\ProfileException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */