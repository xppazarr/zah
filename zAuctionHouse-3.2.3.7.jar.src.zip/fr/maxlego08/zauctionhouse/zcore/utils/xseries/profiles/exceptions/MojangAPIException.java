/*    */ package fr.maxlego08.zauctionhouse.zcore.utils.xseries.profiles.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MojangAPIException
/*    */   extends ProfileException
/*    */ {
/*    */   public MojangAPIException(String paramString) {
/* 30 */     super(paramString);
/*    */   }
/*    */   
/*    */   public MojangAPIException(String paramString, Throwable paramThrowable) {
/* 34 */     super(paramString, paramThrowable);
/*    */   }
/*    */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\zcor\\utils\xseries\profiles\exceptions\MojangAPIException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */