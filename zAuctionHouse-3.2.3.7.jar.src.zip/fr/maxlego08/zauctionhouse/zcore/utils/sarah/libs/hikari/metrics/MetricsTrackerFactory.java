package fr.maxlego08.zauctionhouse.zcore.utils.sarah.libs.hikari.metrics;

public interface MetricsTrackerFactory {
  IMetricsTracker create(String paramString, PoolStats paramPoolStats);
}


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\zcor\\utils\sarah\libs\hikari\metrics\MetricsTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */