package fr.maxlego08.zauctionhouse.zcore.utils.sarah.logger;

public interface Logger {
  void info(String paramString);
}


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\zcor\\utils\sarah\logger\Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */