/*   */ package fr.maxlego08.zauctionhouse.zcore.utils.folialib.impl;
/*   */ 
/*   */ import fr.maxlego08.zauctionhouse.zcore.utils.folialib.FoliaLib;
/*   */ 
/*   */ public class LegacyPaperImplementation
/*   */   extends LegacySpigotImplementation
/*   */ {
/*   */   public LegacyPaperImplementation(FoliaLib paramFoliaLib) {
/* 9 */     super(paramFoliaLib);
/*   */   }
/*   */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\zcor\\utils\folialib\impl\LegacyPaperImplementation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */