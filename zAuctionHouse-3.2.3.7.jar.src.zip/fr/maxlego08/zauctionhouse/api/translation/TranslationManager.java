package fr.maxlego08.zauctionhouse.api.translation;

import org.bukkit.inventory.ItemStack;

public interface TranslationManager {
  String translateItemStack(ItemStack paramItemStack);
  
  String replaceValue(String paramString);
}


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\translation\TranslationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */