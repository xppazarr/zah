package fr.maxlego08.zauctionhouse.api.blacklist;

import org.bukkit.inventory.ItemStack;

public interface ItemChecker {
  String getName();
  
  boolean checkItemStack(ItemStack paramItemStack);
}


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\blacklist\ItemChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */