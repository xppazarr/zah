/*    */ package fr.maxlego08.zauctionhouse.api.exceptions;
/*    */ 
/*    */ 
/*    */ public class InventoryAlreadyExistException
/*    */   extends Error
/*    */ {
/*    */   private static final long serialVersionUID = -5611455794293458580L;
/*    */   
/*    */   public InventoryAlreadyExistException() {}
/*    */   
/*    */   public InventoryAlreadyExistException(String paramString, Throwable paramThrowable, boolean paramBoolean1, boolean paramBoolean2) {
/* 12 */     super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
/*    */   }
/*    */ 
/*    */   
/*    */   public InventoryAlreadyExistException(String paramString, Throwable paramThrowable) {
/* 17 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */   
/*    */   public InventoryAlreadyExistException(String paramString) {
/* 22 */     super(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public InventoryAlreadyExistException(Throwable paramThrowable) {
/* 27 */     super(paramThrowable);
/*    */   }
/*    */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\exceptions\InventoryAlreadyExistException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */