/*    */ package fr.maxlego08.zauctionhouse.api.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemCreateException
/*    */   extends Error
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ItemCreateException() {}
/*    */   
/*    */   public ItemCreateException(String paramString, Throwable paramThrowable, boolean paramBoolean1, boolean paramBoolean2) {
/* 16 */     super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemCreateException(String paramString, Throwable paramThrowable) {
/* 21 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemCreateException(String paramString) {
/* 26 */     super(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemCreateException(Throwable paramThrowable) {
/* 31 */     super(paramThrowable);
/*    */   }
/*    */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\exceptions\ItemCreateException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */