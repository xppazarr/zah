/*    */ package fr.maxlego08.zauctionhouse.api.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemFlagException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ItemFlagException() {}
/*    */   
/*    */   public ItemFlagException(String paramString) {
/* 15 */     super(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemFlagException(Throwable paramThrowable) {
/* 20 */     super(paramThrowable);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemFlagException(String paramString, Throwable paramThrowable) {
/* 25 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemFlagException(String paramString, Throwable paramThrowable, boolean paramBoolean1, boolean paramBoolean2) {
/* 30 */     super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
/*    */   }
/*    */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\exceptions\ItemFlagException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */