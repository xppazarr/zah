/*    */ package fr.maxlego08.zauctionhouse.api.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ButtonsNotFoundException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ButtonsNotFoundException() {}
/*    */   
/*    */   public ButtonsNotFoundException(String paramString) {
/* 28 */     super(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ButtonsNotFoundException(Throwable paramThrowable) {
/* 36 */     super(paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ButtonsNotFoundException(String paramString, Throwable paramThrowable) {
/* 45 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ButtonsNotFoundException(String paramString, Throwable paramThrowable, boolean paramBoolean1, boolean paramBoolean2) {
/* 57 */     super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
/*    */   }
/*    */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\exceptions\ButtonsNotFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */