/*    */ package fr.maxlego08.zauctionhouse.api.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ButtonTypeException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ButtonTypeException() {}
/*    */   
/*    */   public ButtonTypeException(String paramString) {
/* 28 */     super(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ButtonTypeException(Throwable paramThrowable) {
/* 36 */     super(paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ButtonTypeException(String paramString, Throwable paramThrowable) {
/* 45 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ButtonTypeException(String paramString, Throwable paramThrowable, boolean paramBoolean1, boolean paramBoolean2) {
/* 56 */     super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
/*    */   }
/*    */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\exceptions\ButtonTypeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */