/*    */ package fr.maxlego08.zauctionhouse.api.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InventorySizeException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public InventorySizeException() {}
/*    */   
/*    */   public InventorySizeException(String paramString) {
/* 28 */     super(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InventorySizeException(Throwable paramThrowable) {
/* 36 */     super(paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InventorySizeException(String paramString, Throwable paramThrowable) {
/* 45 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InventorySizeException(String paramString, Throwable paramThrowable, boolean paramBoolean1, boolean paramBoolean2) {
/* 57 */     super(paramString, paramThrowable, paramBoolean1, paramBoolean2);
/*    */   }
/*    */ }


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\exceptions\InventorySizeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */