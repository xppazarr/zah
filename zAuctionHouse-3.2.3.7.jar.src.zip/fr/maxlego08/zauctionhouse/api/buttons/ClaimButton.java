package fr.maxlego08.zauctionhouse.api.buttons;

import fr.maxlego08.menu.api.button.Button;

public abstract class ClaimButton extends Button {}


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\buttons\ClaimButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */