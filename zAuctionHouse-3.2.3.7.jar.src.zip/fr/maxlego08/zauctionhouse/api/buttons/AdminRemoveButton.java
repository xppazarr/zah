package fr.maxlego08.zauctionhouse.api.buttons;

import fr.maxlego08.menu.api.button.Button;

public abstract class AdminRemoveButton extends Button {
  public abstract boolean isSilent();
  
  public abstract boolean isForceRemove();
}


/* Location:              D:\ark\zAuctionHouse-3.2.3.7.jar!\fr\maxlego08\zauctionhouse\api\buttons\AdminRemoveButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */